/**
 * dsh-effort-auto-toggle host plugin.
 *
 * A fork of dsh-adaptive-effort with a different arming model: an Auto
 * toggle button next to the model selector in the composer. Lit = the
 * scheduler picks `reasoning_effort` for every request; dim = native manual
 * picking (the effort dropdown stays untouched — no fake "auto" entry is
 * injected, which is what caused UNSUPPORTED_REASONING_EFFORT errors in the
 * original plugin).
 *
 * Since 0.2.0 tiers are model-adaptive: the host `llm` service
 * (resolveModelInfo) supplies the model's real effort list (e.g. glm-5.3 is
 * low/high/max; other adapters may list low/high/highx/max/ultra) and the
 * scheduler maps its three semantic tiers onto that ladder (lightest /
 * upper-middle / heaviest). The lit button and per-reply badges show the
 * real effort id (English, as the adapter names it), sourced live from the
 * modelSelection session projection.
 *
 * Scoring: a MiniMax-compatible chat completion call (thinking disabled —
 * fast and cheap; zero-dependency heuristic fallback when the key/network is
 * unavailable; a failure is negatively cached for 60 s so a dead endpoint is
 * not re-paid on every step, then retried), heavy tool payloads may only
 * upgrade the tier, graded by payload size since 0.3.4 (>= 800 argument
 * characters buys one rung on low -> high -> max, >= 3200 buys two), manual
 * wire picks in the model selector
 * always win, and forced-thinking models (GLM-5.3) get a manual `off`
 * clamped to the ladder's lightest rung instead of an API error. Every
 * decision plus the observed per-step token usage lands in a JSONL ledger
 * (~/.dsh/effort-auto-toggle) with a markdown report (lib/report.js).
 *
 * Extension points:
 * - `session/event` usage records — the ledger's PRIMARY write path since
 *   0.3.4: a usage row lands as soon as the host reports it, deduped by
 *   `session:turn:step`, so accounting no longer depends on a deprecated hook;
 * - `agent/request` waterfall (registered `prepend` so the session
 *   model-selection assembly cannot overwrite the decision; on 0.2.2+ hosts it
 *   is read-only and kept only for the payload plus a catch-up sweep);
 * - `llm` service: resolveModelInfo for per-model effort ladders;
 * - `settings` service (modern describe/update API, ns = profile entry id)
 *   for runtime-adjustable toggles — the volatile fields below.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { minimaxClassify, type ClassifyResult, type FetchLike } from './classifier.ts';
/** Plugin settings (volatile fields are editable on the settings card). */
export interface AdaptiveEffortConfig {
    /** Master switch. */
    enabled: boolean;
    /**
     * The composer Auto button state, persisted through the settings
     * service: lit = auto scheduling on, dim = native manual picking.
     */
    autoOn: boolean;
    /** Scorer backend: `minimax` (LLM) or `heuristic` (zero-dependency). */
    mode: 'minimax' | 'heuristic';
    /** Scorer API key (any OpenAI-compatible chat endpoint). */
    minimaxApiKey: string;
    /** Scorer endpoint (chat-completions base URL). */
    minimaxBaseUrl: string;
    /** Scorer model (any fast model; thinking is disabled on the call). */
    minimaxModel: string;
    /**
     * Scorer call timeout; on expiry fall back to the heuristic (result not
     * cached, so the next message retries the scorer).
     */
    scoreTimeoutMs: number;
    /** Heavy tool payloads may upgrade the tier (continuity, per-session). */
    allowToolUpgrade: boolean;
    /** Clamp a manual `off` to the ladder's lightest rung on GLM-5.3-like models. */
    clampForcedThinkingOff: boolean;
    /** Ledger directory (empty = `~/.dsh/effort-auto-toggle`). */
    ledgerDir: string;
    /**
     * Last decision as a one-line chip (`low · minimax 12 → low`), written into
     * the same settings save as `statsSummary` and shown in the button tooltip.
     */
    lastDecision: string;
}
/** Composition-entry schema (cordis.yml `config:` of the plugin row). */
export declare const Config: z<AdaptiveEffortConfig>;
/** Settings defaults, kept in lockstep with the schema. */
export declare const DEFAULT_CONFIG: AdaptiveEffortConfig;
/** Locale/legacy dictionary namespace id used by the client bundle. */
export declare const SETTINGS_NAMESPACE = "effort-auto-toggle";
/**
 * Plugin body.
 * @param ctx - host context carrying the agent-event dispatch.
 * @param config - resolved plugin configuration.
 */
export declare function apply(ctx: Context, config?: AdaptiveEffortConfig): void;
/**
 * The one-line savings chip (`saved ~23% output tokens vs always-max (121 steps)`),
 * computed from the per-session accumulator. Empty until three steps are known.
 */
export declare function statsSummaryOf(sig: {
    steps: number;
    outTokens: number;
    tierOut: Map<string, number>;
    tierSteps: Map<string, number>;
} | undefined): string;
/** Exposed for tests: rebuild a ledger-backed report for a session id. */
export declare function reportFor(sessionId: string, dir?: string): Promise<string>;
/** Test seam: classify with an injected fetch (never used by apply()). */
/** Test seam: forget every resolved model ladder (capacities are cached per process). */
export declare function __resetModelCache(): void;
/**
 * Test seam: feed the observed-selection baseline (normally fed by
 * `agent/model` reads). Returns whether the value counts as a user pick.
 */
export declare function __noteObservedEffort(sessionId: string, observed: string | undefined): {
    manual: boolean;
    echo: boolean;
};
export declare const __classify: {
    minimax: (text: string, options: Parameters<typeof minimaxClassify>[1], fetchImpl: FetchLike) => Promise<ClassifyResult>;
};
