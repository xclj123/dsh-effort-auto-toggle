# 变更记录

## 0.4.0 — 2026-11-26

P1 from the rc.5 review, minus the session projection (deliberately not taken:
it would drag in a `zod` dependency for a state schema the framework can only
duck-type). Everything here is host-API-free or uses an API the host actually
exposes to a local plugin.

- **Added: durable plan rows.** A decision is now written as its own
  `{"kind":"plan",…}` ledger row the moment it is made, not kept only in the
  in-memory `pending` map. A restart, a restored session, or a second process
  picking up the same ledger can still attribute a usage row to the decision
  behind it; `Ledger.loadIndex()` reads the newest plan per `turn:step` in one
  pass at startup. Report rows and plan rows never mix (`isLedgerRecord`
  rejects `kind === 'plan'`).
- **Added: manual-vs-echo baseline (0.4.0).** `agent.model.current()` returns
  our own last write on the next step, so "the user hand-picked this" and "this
  is our echo" look identical. A per-session baseline diff now answers it:
  first sight records the baseline, an observed value equal to the baseline is
  an echo, a different one is a user pick (and becomes the new baseline). This
  replaces the fragile 30-second `plan_echoCheck` heuristic as the primary
  signal.
- **Added: decision chip.** The button tooltip gains a `last decision` line
  (`low · minimax 12 → low`), written in the same `settings.update` call as the
  savings line — no second enumeration on the hot path.
- **Added: `/effort` command.** `status` (default), `on`, `off`, `low`, `high`,
  `max`. It reports the switch, the model, the ladder, the wire effort, the last
  decision and the savings line; an unknown argument and a model with no dial
  both answer with a plain error instead of doing something surprising.
  Registered through `ctx.inject(['commands'])`, so a host without the service
  simply never sees it.
- **Added: cost estimate and `prices.json`.** `lib/pricing.js` carries 16
  catalog entries (deepseek / glm / minimax / kimi / qwen / doubao) with
  per-million rates, the date each was checked and where it came from, plus
  DeepSeek's Beijing peak/off-peak schedule. Aliases match on segment
  boundaries, never `includes`: `glm-5` must not price `glm-5.3`. Prices are
  resolved at report time and **never stamped into a ledger row**, so fixing a
  price re-prices the entire history. Models outside the catalog are counted as
  `未计价` instead of guessed; `<ledger dir>/prices.json` overrides any of them
  (keyed by `provider`, `model` or `provider|model`).
- **Added: `tools/check.mjs`.** A dependency-free self-check: every runtime
  module has a `.d.ts` whose exports match, the packed `files` list plus
  `types` / `dsh.bundle.patch` / `exports["./client"]` all resolve, and nothing
  but `readEvents()` may touch `session.events`. `npm run check`.
- **Fixed: two `title` props on the button.** The second one silently replaced
  the first, so the hint disappeared as soon as the savings line arrived.
- **Fixed: `priceFor` ignored already-parsed overrides.** `prices.json` is
  parsed by the report, and the old `parseOverrides` only accepted a string —
  a user's own rates were silently dropped.
- Tests: 65 → 77 (baseline echo vs pick, plan rows and cross-process
  attribution, `/effort` status/off/pin/unknown/no-dial, alias boundaries,
  peak windows, per-slot cost arithmetic, unpriced steps, "prices never enter
  the ledger").

## 0.3.5 — 2026-11-26

P0 from the DSH 0.2.2-rc.5 review: the ledger stopped replaying itself, the hot
path stopped enumerating settings, and a model without a reasoning dial is no
longer scheduled against.

- **Fixed: a third of the ledger was replay.** `agent/request` swept from
  `scannedIndex.get(sessionId) ?? -1`, so the first request after a restart
  re-read the whole session log and wrote every historical usage row back out —
  on real data **5,693 of 10,385 rows were duplicates**. Two gates now hold:
  the first sight of a session seeds from the log's end instead of the
  beginning, and `Ledger` loads the on-disk `sessionId|turn:step` key set once
  at startup so a row can never be written twice even across processes.
- **Fixed: `describe()` ran on every request.** The volatile settings fields
  handed to `apply()` are live `{get()}` refs (`loader/volatile-update`
  commits in place), so the config is now read straight off them — one
  `describe()` enumeration per `agent/request` is gone from the hot path.
- **Fixed: models with no reasoning dial got scheduled anyway.** A route whose
  model info carries no `reasoning` block (or answers
  `INVALID_MODEL_REASONING`) is remembered as an empty ladder: no claim-time
  select, no scheduling, no `off` clamping — the seed rides through untouched.
  Transient failures (transport, unknown model) still fall back to the default
  ladder and are retried. This is the `UNSUPPORTED_REASONING_EFFORT` class of
  bug, closed on our side before it can fire.
- **Fixed: the report priced duplicates.** `buildReport` folds rows by
  `session:turn:step` and reports how many it dropped
  (`会话步骤数：N（已剔除重放重复行 M）`), so token totals and savings stop
  counting the same step twice. Legacy level ids (`minimal`/`medium`, and
  toggle-only `on`) now have a real rank instead of sorting past `max` and
  becoming the savings ceiling.
- **Docs:** `engines.dsh` declares the host range actually tested
  (`>=0.2.1 <0.3.0-0`); the compatibility lists in both READMEs were re-verified
  against the 0.2.2-rc.5 asar.
- Tests: 60 → 65 (`a restored session is not replayed into the file`,
  `a row already on disk survives a restart without being written twice`,
  `replay duplicates are folded and counted`, two capability-guard cases,
  `volatile refs are read directly, without settings.describe()`).

## 0.3.4 — 2026-11-17

The three follow-ups from the 0.3.3 review, plus the accounting moved off a
deprecated upstream hook.

- **Fixed: the 800–3199 dead zone in the scheduler.** Any tool call under 3200
  characters was a no-op — the code logged "below the upgrade threshold" and
  changed nothing, so a 3000-character `apply_patch` counted for exactly as much
  as a bare `ls`. Escalation is now graded: ≥800 chars buys one rung, ≥3200
  buys two (`rungsForArgs`), saturating at the top of the ladder. A `low`
  verdict with a 2000-character call now runs `high` instead of `low`.
- **Fixed: continuity and the scheduler double-counted the same evidence.**
  With graded rungs the old standalone continuity lift became a second opinion
  on the same tool calls (low → continuity high → one more rung → max). The
  continuity lift is gone; continuity now owns only the *time window*
  (`CONTINUITY_WINDOW_MS`) and the scheduler owns the *size policy*
  (`rungsForArgs`). One decision, one place.
- **Added: scorer backoff.** A scorer failure was correctly not cached as a
  verdict, but that also meant every later step in the same turn re-paid the
  full `scoreTimeoutMs` against a dead endpoint. `ScorerBackoff` remembers the
  *failure* for 60 s (bounded at 128 entries), so the heuristic verdict applies
  immediately and the network attempt waits for a human-scale retry.
- **Fixed: the ledger no longer depends on the deprecated `agent/request` hook.**
  Usage rows are now written the moment the host reports them, straight from the
  `session/event` stream. `agent/request` is kept only as a catch-up sweep for
  rows that predate the plugin or arrive on a host whose event stream is not
  wired; `recordUsage()` dedupes by `session:turn:step`, so the two paths cannot
  double-write. `agent/request` is `@deprecated` upstream ("do not add new
  listeners"), and the click-time decision already rides `agent.model.select()`.
- **Fixed: ledger rows could be written out of order.** Appends are
  fire-and-forget, so a live step-2 row could race the catch-up sweep's step-1
  row and land first — `report --last` then read a session shuffled. `Ledger`
  now chains its writes through an internal promise queue, keeping the file
  chronological without making any caller wait.
- **Added: claim-time attribution.** The claim decision is published onto the
  turn's first step in `pending`, so a session logs a real `tier` /
  `classifierSource` even on a host that never calls `agent/request` at all.
- Tests: 47 → 60.

## 0.3.3 — 2026-11-17

dsh 0.2.2-rc.3 compatibility pass, plus the routing fix the ledger was pointing at.

- **Fixed: no usage reached the ledger on rc.3.** `Session` lost its `events`
  getter in 0.2.2-rc.3, so every read returned `[]` and usage rows fell through
  to the `unknown` fallback. `readEvents()` now probes `snapshotEvents()` →
  `ownEvents()` → `eventAt()`/`seq` → the legacy `events` array, in that order,
  so both rc.3 and older hosts are covered.
- **Fixed: a light tool call counted as continuity.** Any `tool/call` in the
  last 10 minutes pinned a `low` verdict to high (or max), so a bare `ls`
  between two chat messages kept the whole session expensive. Continuity now
  requires a call with at least 800 characters of arguments — the same floor the
  scheduler already uses for a heavy call. In the local ledger 2825 of 4155
  classified rows had been lifted this way.
- **Fixed: continuity climbed the ladder by itself.** The lift target was
  `lastOverride.effort === last rung ? 'max' : 'high'`, and every scheduled step
  rewrites `lastOverride.effort` with the effort it just picked. So the first
  time one step reached max, every subsequent low verdict was lifted straight to
  max — a conversation scored 20 throughout (a plain "simple") marched
  low → high → max on its own. One continuity lift now means exactly one rung
  (`high`), with no read of the previous pick.
- **Fixed: the heuristic half could overrule the scorer.** The fusion rule was
  "whichever score is higher wins", so a single keyword from the heavy list
  (or a long paste) replaced a confident `low`. The scorer is now authoritative;
  the heuristic only overrides when it has an explicit heavy pile-up (score ≥ 70)
  against a low verdict.
- **Fixed: the report dropped highx/ultra rows.** `buildReport` bucketed on the
  wire effort id against a hardcoded `low/high/max` list, so five-level models
  landed in no bucket at all. The report now groups *dynamically* by the effort
  that actually ran (lightest first, unknown ids last) and prints the
  classifier's own verdict as a second table — a verdict is not a run, so a
  semantic `low` on a single-level model shows up as `high` in both.
- **Fixed: the savings estimate could read zero.** The counterfactual was
  "non-max steps × (max mean − overall mean)", which silently collapsed because
  the heaviest bucket is often made of *short* steps (a max step that answers in
  one line) and the max mean could sit below the high mean. It is now
  `steps × costliest-observed-mean − actual total`. On the local ledger this
  moved the number from 0 to ~1.4M tokens.
- **Added: prompt-cache accounting.** Ledger rows now carry `cacheReadTokens` /
  `cacheWriteTokens`; dsh reports usage counts disjointly, so `inputTokens`
  alone was only the uncached half of the prompt.
- **Fixed: client dependency list.** `dsh.client.inject` named
  `dsh-client-runtime` and `dsh-client-ui-slots`, neither of which exists in
  rc.3. Replaced with the four packages that actually serve `slots` / `locale` /
  `configForms` / `remote.settings` today.
- Tests: 40 → 47, and the host mock now mirrors the rc.3 session shape
  (`snapshotEvents`, no `events`) instead of the legacy array, so this class of
  drift fails the suite instead of production.

## 0.3.2 — 2026-11-14

Signal engine scoped down to keep the plugin's original promise: simple messages run cheap.

- Removed the retry / long-context / prior-hard-turn boosts introduced in 0.3.0 — none of them may pin a message away from low on its own merits.
- Kept: tool-failure boost (2+ real tool failures within 10 min stop the next low) and the calm drop (two consecutive short successful turns drop heuristic highs back to low; minimax verdicts are never overridden).
- Kept: the savings tooltip.
- 40 tests green.

## 0.3.1 — 2026-11-14

True failure signals on top of 0.3.0.

- Failure boost: two failed tool results within 10 minutes (non-zero exit codes, timeouts, tracebacks, sandbox denials) stop the next message from scheduling low.
- Calm drop: after two consecutive short successful turns (≤6 steps, no failures), heuristic-source highs drop back to low; minimax verdicts are never overridden.
- Streak settle now runs once per turn at claim time (request-step double settle fixed).
- 43 tests green.

## 0.3.0 — 2026-11-14

- Adaptive signals: resending the same message within 3 min bumps the tier (retry boost); conversations over 100k input tokens never schedule low (context boost); a hard prior turn (12+ steps) pins the next low up to high (difficulty boost).
- Savings stats: hover the toggle button to see live 'saved ~N% output tokens vs always-max' (per-session accumulator, pushed to settings at most every 30 min).
- Key tip card: pinned light glass styling (0.2.9).

## 0.2.9 — 2026-11-14

- First-run key tip card: pinned light glass styling (white card, dark text) so it reads well on any theme; softer shadow.

## 0.2.8 — 2026-11-06

- Root-caused the "toggle cannot be disarmed" reports on DSH 0.2.2-rc.1: the
  breakage comes from dsh-ops < 0.5.0, which poisons the host settings
  write path for every plugin when force-loaded on 0.2.2. Upgrade dsh-ops
  to 0.5.0+ (or remove its version exemption) and settings writes recover;
  this plugin's remote.settings channel was correct all along.
- Write diagnostics: refused RPC answers now log the thrower message and
  stack head to the console (JSON.stringify hides prototype-chain
  properties such as error.message).
- Key tip copy now points at the durable key management entry:
  Settings > Plugin Market > Installed > dsh-effort-auto-toggle (the host
  renders the full volatile form there — key, endpoint, scorer model, mode).

## 0.2.7 — 2026-11-06

- Fixed the toggle button on DSH 0.2.2-rc.1: client writes now go through the
  official remote.settings RPC (permission-presets precedent) instead of the
  broken form.set path, falling back to scope.set on older hosts.
- Reverted the 0.2.6 arming workaround: the armed source of truth is the
  settings value again (liveCfg per request), override-state.json is back to
  pure override memory (effort / preAutoEffort).
- The toggle can be pressed repeatedly again (arm and disarm at will).
(0.2.6 was an unpublished local workaround build.)

## 0.2.5 — 2026-11-05
- Removed the dead `settings.plugin.item` slot injection and the
  `AutoToggleCard` component: that slot does not exist in any DSH host
  build (the real settings card is rendered by the host plugin-manager
  page from `configForms`), so the registration was silently dead
  code. Also dropped the now-orphaned helpers (ToggleRow, MODE_OPTIONS,
  card styles, scopeClear) and the `card.*` locale keys, plus the
  matching test assertions.

## 0.2.4 — 2026-11-05
- First-run key tip: while armed with `mode: minimax` and no key, the
  toggle shows a popover — paste a key (saved straight into plugin
  settings), keep the keyless heuristic mode, or dismiss (remembered in
  localStorage).
- Settings-card field descriptions now spell out the keyless heuristic
  fallback.

## 0.2.3 — 2026-11-05

### Added / Fixed — DSH 0.2.2 host compatibility (dual-mode)

DSH 0.2.2-rc.1 changed how the reasoning effort reaches the provider: the
`agent/request` waterfall result is now validated against the step's fixed
model selection, so rewriting `reasoningEffort` there (the 0.2.2 approach)
fails every step with an effort mismatch. Effort changes must go through the
new `agent.model.select()` API before step preparation.

This release makes the plugin **dual-mode**: it probes each event's agent
instance and switches automatically — no separate builds, no config.

- **New hosts (DSH 0.2.2+)**: the decision fires at `agent/inbox/claimed`
  time (synchronous, so the first step of a turn already runs at the
  scheduled tier) via `agent.model.select()`; `agent/request` becomes
  read-only bookkeeping that also queues refinements (tool-continuity
  bumps, delayed minimax verdicts) for the next step. Disarm-restore and
  the forced-thinking `off` clamp ride the same API.
- **Old hosts (DSH ≤ 0.2.1)**: the previous path is untouched — same
  behaviour, same ledger.
- Ledger reasons now distinguish the model.select path (`scheduled
  (model.select path)`, `select X queued for next step`), and first-step
  attribution reuses the claim-time decision (classifier source included).

## 0.2.2 — 2026-10-30

### Fixed

- Badge click now jumps to the head of the badge's own turn. The badge is rendered by the host TurnTailNodeView (`data-turn-tail`), an independent row placed AFTER the assistant content, so the previous nearest-anchor lookup aligned that tail and visually landed on the next message. We now resolve the turn number and align its first `[data-chat-turn]` row exactly like the host `ChatScroller.scrollToTurn`, with the outermost-anchor lookup kept as a fallback.

## 0.2.1 — 2026-10-30

### 修复：消息角标点击回到回复开头不生效
- 行定位改用宿主 ChatScroller 的行标识 `data-chat-anchor-key`（原来的
  `data-chat-flow-kind` 只是类型标记，closest 可能落到嵌套的步骤子行上）。
- 滚动姿势改照宿主 `ChatScroller.align`：对该行与 `[data-conversation-scroll]`
  滚动容器求 delta 后直接写 `scrollTop`（顶部留 24px，同宿主 `scrollToTurn`）。
  原来的裸 `scrollIntoView` 在嵌套滚动容器 + 虚拟列表 scroller 的自管状态下会被
  吞掉或滚错容器；无 scroller 时仍回退 `scrollIntoView`。

## 0.2.0 — 2026-10-30

### 模型自适应档位（breaking 行为改进）
- 档位不再写死 `low/high/max`：每次请求向宿主 `llm` 服务查当前模型的真实档位表
  （`resolveModelInfo(provider, model).reasoning.efforts`，如 glm-5.3 的 `low/high/max`，
  或其它 adapter 的 `low/high/highx/max/ultra`），调度器内部三档语义映射到该表：
  轻 → 最轻档、重 → 最重档、中 → `floor((n-1)*2/3)` 位（3 档→第 2 档，5 档→第 3 档）。
  llm 服务不可用时回落 `DEFAULT_LADDER`（下次重试）。
- 非自动模式手选任意真实档位（如 `ultra`）原样透传，不再被旧白名单误清洗。

### 显示改英文原文
- 按钮点亮时显示档位原文：`自动·low` / `自动·highx` / `自动·ultra`（档名就是 adapter 自己的命名）。
- 消息角标同步：`glm-5.3 · low`。数据源 = modelSelection 会话投影的 `lastUsed`
  （每请求 `request/header` 事件回填的真实档位），点亮时按钮实时跳动。

### 其它
- 启发式打分：≥3 个 heavy 关键词直接 70 分（max 语义）；本版测试覆盖 5 档模型端到端
  （low→low、2 关键词+代码块→highx、5 关键词→ultra）。
- `tools/install.mjs`：不给 `--profile` 时自动探测并列出 `~/.dsh/profiles` 下的 profile；
  yaml 注释块同步新语义。
- `package.json`：description 更新；删除从未使用的构建链 devDependencies
  （tsc/tsdown/vitest/types），测试是零依赖 `node --test`。
- `lib/*.d.ts` 全量对齐 0.2.0 导出（effort.d.ts 补 buildLadder/semanticToLadder/guessSemantic/
  isPickableEffort/assertScheduledEffort/isOffLikeId/DEFAULT_LADDER；index.d.ts 换 autoOn 配置面）。

## 0.1.7 — 2026-10-30

- 按钮档位显示的数据源修复：cordis client ctx 上 `ctx.sessions` 恒 undefined（client 服务
  只经 `ctx.inject` 的 scope 暴露）。宿主侧先例（官方 model-selection）：`ctx.inject(["sessions"],
  (scope) => { const sessions = scope.sessions; ... })`——client.js 现在用嵌套 inject 捕获
  `sessionsRef`，modelFace 回落链 `sessionsRef || ctx.get("sessions") || ctx.sessions`。
  （0.1.6 首次实现按钮档位显示，但走了恒空的 `ctx.sessions`，按钮只显示「自动」不带档。）

## 0.1.6 — 2026-10-30

- 点亮的「自动」按钮实时显示当前调度档位（订阅 modelSelection 会话投影 faceOf；
  `conversation.input.right` 插槽的 inject 回调 `(sessionId) => props` 拿会话 id）。
- 通道考古结论（asar 源码）：宿主→client 无任意事件转发（API_REMOTE_FORWARDED_EVENTS 封闭枚举），
  官方推荐通道 = session projection `wire.view`；modelSelection 投影 `pending`（手选意图）只在
  请求档位恰等于手选值时消化——自动调度下手选显示不消化属宿主语义，未改动。

## 0.1.5 — 2026-10-30

- 会话隔离的连续性保护：低档连续性保护（10 分钟窗口）现在只统计**同一会话**的工具调用。此前宿主进程里
  任意会话（例如几分钟前一个工具密集的会话）都会把新会话的闲聊消息（「你好」）经 minimax+continuity
  顶到 high。其它会话的 usage 行也不再被冲进请求会话的账本。



## 0.1.1 — 2026-10-30

### 修复
- **`auto` 泄漏导致 `UNSUPPORTED_REASONING_EFFORT`**：按钮熄灭（passthrough）时不再盲信快照里的
  `reasoningEffort`。任何不是 `low|high|max` 的值（`auto`、`medium`、空串、垃圾值）都会在发请求前
  被替换成「进入自动前的档位 → 当前手动档位 → `high`」，并记一条 warn：
  `effort "%s" is not accepted by the provider; sending "%s" instead`。
- **熄灭后还原**：从点亮切回熄灭的第一个请求会写回 `preAutoEffort`（进入自动前用户选的那档），
  之后按手动档位直通，不再把 `auto` 留在会话快照里。
- 按钮熄灭且不需要消毒时仍然 `return seed`（对象零改动），不做无意义的请求改写。

### 变更
- `npm test` 改为 `node --test test/`（原来的 `vitest run` 在没有 devDependency 的机器上跑不起来），
  并新增 `test:host` / `test:client` 两个单测入口。
- 新增 `tools/install.mjs`：把插件装进**指定** profile（默认拒绝 `desktop`），幂等、带备份、支持
  `--dry-run` / `--remove`。
- README 按 fork 的实际行为重写（原来还是上游 dsh-adaptive-effort 的说明）。

### 验证
- `node --test test/` → 13 passed（8 宿主 + 5 前端）。
- 安装脚本在临时 profile 上跑过 install → install（幂等）→ remove 全链路，
  `cordis.patch.yml` 与 `package.json` 都能回到原样；`desktop` profile 被正确拒绝。

## 0.1.0 — 2026-10-30

- 从 `dsh-adaptive-effort@0.3.0` fork 出来的初版：去掉「推理等级列表里的自动档」，改成输入栏的
  自动按钮（`conversation.input.model` 插槽，id `effort-auto-toggle-button`），点亮走调度、熄灭走人工；
  设置卡片与回复徽标一并继承。

